VIRUS INI HANYA UNTUK EDUKASI

Efek pada komputer: performa cpu akan menjadi ~100%